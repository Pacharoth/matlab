x= 1:5; %set 5 value
y=rand(1,5);    %random 5 values as vector
bar(x,y,'r');    %draw graph x and y using red color as bar of each value