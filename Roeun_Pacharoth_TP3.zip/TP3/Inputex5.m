%I cannnot make the same linewidth
x=0;
y=0;
circle2(x,y,1,[0,0.45,0.74],5);
circle2(x,y,2,[0.3,0.75,0.93],2);
circle2(x,y,3,[0.47,0.67,0.19],3);
circle2(x,y,4,'yellow',4);
circle2(x,y,5,[0.87,0.49,0],3);
