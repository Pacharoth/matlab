subplot(2,2,1)
triangle(-4,-2,-3,7,4,-2) %this ffrom triangle coordinate
%square
subplot(2,2,2)
square(3,2,4) %the same length for each size when u zoom u will know it is square or remove xlim and ylim
%rectangle
subplot(2,2,3)
rectangle1(-1,2,5,6)% not the same size but when u zoom u will know the size or remove xlim and ylim